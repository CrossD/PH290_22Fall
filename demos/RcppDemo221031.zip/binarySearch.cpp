#include <cmath>
#include <Rcpp.h>
using namespace Rcpp;

int bs (double* A, int n, double v) {
    int cand = n / 2;
    if (n == 1) {
        if (A[0] == v) {
            return(0);
        } else {
            return(-n);
        }
    } else if (A[cand - 1] >= v) {
        return(bs(A, cand, v));
    } else {
        return(bs(A + cand, n - cand, v) + cand);
    }
}

// [[Rcpp::export()]]
int binarySearchCpp(NumericVector A, double v) {
  return(bs(A.begin(), A.size(), v) + 1);
}

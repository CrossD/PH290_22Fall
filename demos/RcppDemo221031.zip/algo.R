binarySearch <- function(A, v) {
    cand = floor(length(A) / 2)
    if (length(A) == 1) {
        if (A == v) {
            return(1L)
        } else {
            return(-Inf)
        }
    } else if (A[cand] >= v) {
        binarySearch(A[1:cand], v)
    } else {
        binarySearch(A[(cand+1):length(A)], v) + cand
    }
}



library(Rcpp)
sourceCpp("binarySearch.cpp")
# binarySearch(1, 6)
# set.seed(1)
# x <- sort(rnorm(1e6))
# v <- sample(x, 1)

res <- bench::press(n = 10^(4:7),
             {
  x <- sort(rnorm(n))
  v <- x[round(3/4 * n)]
  bench::mark(
    which(x == v), # linear search, grows linearly
    binarySearch(x, v), 
    binarySearchCpp(x, v)
  )
             })
# res
ggplot2::autoplot(res)
summary(res)

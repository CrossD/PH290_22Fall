## code to prepare `stock` dataset goes here

usethis::use_data(stock, overwrite = TRUE)

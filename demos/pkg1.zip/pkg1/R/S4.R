# #' @export
setClass("patient", slots=c(name = "character", ID = "numeric"))

# #' @export
setMethod("show", "patient", 
          function(object) writeLines(sprintf("%s has ID %d", object@name, object@ID)))


# a <- new("patient", name="Jack", ID=100)


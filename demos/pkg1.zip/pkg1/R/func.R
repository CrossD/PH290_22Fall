#' Create, modify, and delete columns
#'
#' `mutate()` adds new variables and preserves existing ones;
#' `transmute()` adds new variables and drops existing ones.
#' New variables overwrite existing variables of the same name.
#' Variables can be removed by setting their value to `NULL`.
#'
#' # Useful mutate functions
#'
#' * [`+`], [`-`], [log()], etc., for their usual mathematical meanings
#'
#' ...
#'
#' # Grouped tibbles
#'
#' Because mutating expressions are computed within groups, they may
#' yield different results on grouped tibbles. This will be the case
#' as soon as an aggregating, lagging, or ranking function is
#' involved. Compare this ungrouped mutate:
#' 
#' @importFrom praise praise
f <- function(...) {
  praise()
}

#' Compare two models
#'
#' Compare two models according to what their `summary()` method prints out
#'
#' More details: This is a very rudimentary implementation. The two models are compared according to the text output of the `summary()` method
#' 
#' - item1
#' - item2

CompModels <- function(mod1, mod2, ...) {
  f1 <- tempfile()
  sink(f1)
  print(summary(mod1))
  sink()

  f2 <- tempfile()
  sink(f2)
  print(summary(mod2))
  sink()
    
  diffviewer::visual_diff(f1, f2)
}

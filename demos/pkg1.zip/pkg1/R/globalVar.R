global <- 1

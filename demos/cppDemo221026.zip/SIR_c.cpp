extern "C"        // Compile the C++ code into a C-friendly format
void SIR_c(double* dt, double* beta, double* gamma, 
           double* initial, double* res, int* dim) {
  int n = dim[0];
  res[0] = initial[0];
  res[0 + 1 * n] = initial[1];     // stride to index the column:
  res[0 + 2 * n] = initial[2]; // R matrix is a long vector
  double a, b;
  for (int i = 1; i < n; i++) {
    a = *beta * res[i - 1] * res[i - 1 + n] * dt[0];
    b = *gamma * res[i - 1 + n] * dt[0];
    res[i] = res[i - 1] - a;
    res[i + n] = res[i - 1 + n] + a - b;
    res[i + 2 * n] = res[i - 1 + 2 * n] + b;
  }
}
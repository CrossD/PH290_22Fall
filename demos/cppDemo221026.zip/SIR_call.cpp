#include <Rinternals.h>
#include <R.h>
#include <cmath>
extern "C" 
SEXP SIR_cpp0(SEXP Duration, SEXP Dt, SEXP Beta, SEXP Gamma, SEXP Initial) {
  double *duration = REAL(Duration);
  double *dt = REAL(Dt);
  double *beta = REAL(Beta);
  double *gamma = REAL(Gamma);
  double *initial = REAL(Initial);
  int n = std::floor(*duration / *dt) + 1;
  
  SEXP myreturn;
  PROTECT(myreturn = allocMatrix(REALSXP, n, 3));
  double* res = REAL(myreturn);
  res[0] = initial[0];
  res[0 + n] = initial[1];
  res[0 + 2 * n] = initial[2];
  double a, b;
  for (int i = 1; i < n; i++) {
    a = *beta * res[i - 1] * res[i - 1 + n] * dt[0];
    b = *gamma * res[i - 1 + n] * dt[0];
    res[i] = res[i - 1] - a;
    res[i + n] = res[i - 1 + n] + a - b;
    res[i + 2 * n] = res[i - 1 + 2 * n] + b;
  } // ... same as before
  UNPROTECT(1);
  return(myreturn);
}
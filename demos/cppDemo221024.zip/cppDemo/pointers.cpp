#include <iostream>
int f_by_val(int i);
int f_by_pt(int* i) {
    *i += 1; // leave side effect
    return *i;
}
int f_by_ref(int &i) {
    i += 1;
    return i;
}
int main() {
    int a = 0, b = 0, c = 0;
    int* bp=&b;
    int a2 = f_by_val(a);
    f_by_pt(bp);
    f_by_ref(c);
    std::cout << a << "\n"
              << a2 << "\n"
              << b << "\n" 
              << c << "\n"
              << bp << "\n";
    return 0;
}

int f_by_val(int i) { // declaration goes before use
    i += 1; // i = i + 1;
    return i;
}

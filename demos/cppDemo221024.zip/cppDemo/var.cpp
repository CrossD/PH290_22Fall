#include <iostream>
int main() {
    int i;
    int j = 1;
    int l = 3;
    bool k = true;
    double ld = 3.0;
    std::cout << i << "\n" // garbage
              << j / l << "\n"
              << j / ld << "\n" 
              << k << "\n";
    return 0;
}

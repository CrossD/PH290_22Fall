#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double a[3] = {1.5, 3.1, -1.2};
    std::cout << a << "\n"
              << a[0] << "\n"
              << *a << "\n"
              << *(a + 1) << "\n";

    int n;
    cout << "Enter n: \n";
    cin >> n;
    double *arr = new double[n];
    for (int i = 0; i < n; i++) {
        arr[i] = std::pow((double) i, 3.0);
        cout << arr[i] << '\n';
    }
    delete[] arr;
    return 0;
}
